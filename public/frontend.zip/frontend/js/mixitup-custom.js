var mixiEl = document.querySelector('.mixits');
var mixer = mixitup(mixiEl);